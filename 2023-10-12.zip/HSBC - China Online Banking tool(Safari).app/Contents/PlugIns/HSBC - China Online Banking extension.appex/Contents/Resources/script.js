var productID = "com.cfca.hickit.hsbc";

var webRequestEventName  = productID + ".request";
var webResponseEventName = productID + ".response";

document.addEventListener("DOMContentLoaded", function(e) {
    safari.self.addEventListener("message", handleExtensionResponse);
});

document.addEventListener(webRequestEventName, function (e) {
    safari.extension.dispatchMessage(webRequestEventName, { detail: e.detail });
});

function handleExtensionResponse(e) {
    var responseEventName = webResponseEventName;
    
    if (e.message.randomId != undefined) {
        responseEventName += "." + e.message.randomId;
    }
    
    var event = new CustomEvent(responseEventName, { detail: JSON.stringify(e.message) });
    document.dispatchEvent(event);
}
