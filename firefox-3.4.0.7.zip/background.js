var productID = 'com.cfca.hickit.hsbc';
var portArr = {};

browser.runtime.onMessage.addListener(function (
  request,
  sender,
  senderCallback
) {
  try {
    if (request.action == "connect") {
      connectToNativeHost(productID, sender.contextId, senderCallback);
    } else if (request.action == "disconnect") {
      disconnectToNativeHost(sender.contextId, senderCallback);
    } else if (request.action == "getExtensionVersion") {
      getExtensionVersion(sender.tab.id, senderCallback);
    } else if (request.action == "invoke" && ["GetVersion", "GetMacAddress"].includes(request.funcInfo.function)) {
      return sendToNativeHost(request, sender.contextId, senderCallback);
    }
  } catch (e) {
    var resultObj = new Object();
    resultObj.errorcode = 1;
    resultObj.result = e.message;
    senderCallback(resultObj);
  }
});

// connect to native host and get the communication port
function connectToNativeHost(host, tabID, senderCallback) {
  try {
    if (null != portArr[tabID]) {
      portArr[tabID].disconnect();
      delete portArr[tabID];
    }

    var port = browser.runtime.connectNative(host);
    port.onMessage.addListener(onNativeMessage);
    port.onDisconnect.addListener(onDisconnected);
    port.tabID = tabID;
    port.responseArray = {};

    portArr[tabID] = port;

    senderCallback({ errorcode: 0 });
  } catch (e) {
    throw e;
  }
}

function onNativeMessage(message) {
  var receiveEventName = "receiveNativeMsgEvent";
  if (message.randomId != undefined) {
    receiveEventName += "." + message.randomId;
  }
  var evt = document.createEvent("CustomEvent");
  evt.initCustomEvent(receiveEventName, true, false, message);
  document.dispatchEvent(evt);
}

function onDisconnected(port) {
  if (null != portArr[port.tabID]) {
    delete portArr[port.tabID];
  }

  for (var key in port.responseArray) {
    port.responseArray[key]({ errorcode: 4 });
    delete port.responseArray[key];
  }
}

//disconnect from native host
function disconnectToNativeHost(tabID, senderCallback) {
  try {
    if (null != portArr[tabID]) {
      portArr[tabID].disconnect();
      delete portArr[tabID];
    }

    senderCallback({ errorcode: 0 });
  } catch (e) {
    console.log(e.message);
  }
}

//send message from native host
function sendToNativeHost(request, tabID, senderCallback) {
  try {
    var port = portArr[tabID];
    port.postMessage(request.funcInfo);

    return new Promise(function (senderCallback, reject) {
      var receiveEventName = "receiveNativeMsgEvent";
      if (
        request.funcInfo != undefined &&
        request.funcInfo.randomId != undefined
      ) {
        receiveEventName += "." + request.funcInfo.randomId;
      }
      var sendToDocment = function (e) {
        senderCallback(e.detail);
        document.removeEventListener(e.type, sendToDocment);
        delete port.responseArray[receiveEventName];
      };
      port.responseArray[receiveEventName] = sendToDocment;

      document.addEventListener(receiveEventName, sendToDocment, false);
    });
  } catch (e) {
    throw e;
  }
}

function getExtensionVersion(tabID, senderCallback) {
  try {
    var manifest = browser.runtime.getManifest();
    var resultObj = new Object();
    resultObj.errorcode = 0;
    resultObj.result = manifest.version;
    senderCallback(resultObj);
  } catch (e) {
    throw e;
  }
}
