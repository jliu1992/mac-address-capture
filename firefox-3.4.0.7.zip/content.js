var productID = "com.cfca.hickit.hsbc";
var extensionName = productID + ".extension";
var reqEventName = productID + ".request";
var respEventName = productID + ".response";

document.addEventListener(
  reqEventName,
  function (e) {
    browser.runtime.sendMessage(e.detail).then(function (response) {
      var responseEventName = respEventName;
      if (
        e.detail.funcInfo != undefined &&
        e.detail.funcInfo.randomId != undefined
      ) {
        responseEventName += "." + e.detail.funcInfo.randomId;
      }

      var event = new CustomEvent(responseEventName, {
        detail: JSON.stringify(response),
      });
      document.dispatchEvent(event);
    });
  },
  false
);
